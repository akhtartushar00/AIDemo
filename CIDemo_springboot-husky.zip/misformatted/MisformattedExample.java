public class MisformattedExample{public static void main(String[]args){System.out.println("This file is intentionally messy; try committing it to see Husky format it.");}}
