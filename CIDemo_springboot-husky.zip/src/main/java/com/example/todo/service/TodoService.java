
package com.example.todo.service;

import com.example.todo.model.Todo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.stereotype.Service;

@Service
public class TodoService {
  private final List<Todo> store = Collections.synchronizedList(new ArrayList<>());
  private final AtomicLong seq = new AtomicLong(1);

  public List<Todo> findAll() {
    synchronized (store) {
      return new ArrayList<>(store);
    }
  }

  public Todo create(Todo input) {
    long id = seq.getAndIncrement();
    Todo t = new Todo(id, input.getTitle(), Boolean.TRUE.equals(input.getCompleted()));
    store.add(t);
    return t;
  }

  public Optional<Todo> findById(long id) {
    synchronized (store) {
      return store.stream().filter(t -> t.getId() == id).findFirst();
    }
  }

  public void clearAll() {
    synchronized (store) {
      store.clear();
      seq.set(1);
    }
  }
}
