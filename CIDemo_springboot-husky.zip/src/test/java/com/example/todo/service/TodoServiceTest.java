
package com.example.todo.service;

import static org.junit.jupiter.api.Assertions.*;

import com.example.todo.model.Todo;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class TodoServiceTest {
  private TodoService service;

  @BeforeEach
  void setUp() {
    service = new TodoService();
    service.clearAll();
  }

  @Test
  @DisplayName("create() assigns incremental ids and preserves fields")
  void testCreate() {
    Todo a = service.create(new Todo(null, "Task A", false));
    Todo b = service.create(new Todo(null, "Task B", true));

    assertEquals(1L, a.getId());
    assertEquals(2L, b.getId());
    assertEquals("Task A", a.getTitle());
    assertFalse(a.getCompleted());
    assertTrue(b.getCompleted());
  }

  @Test
  @DisplayName("findAll() returns a copy and maintains insertion order")
  void testFindAll() {
    service.create(new Todo(null, "A", false));
    service.create(new Todo(null, "B", true));

    List<Todo> list = service.findAll();
    assertEquals(2, list.size());
    assertEquals("A", list.get(0).getTitle());
    assertEquals("B", list.get(1).getTitle());

    // Ensure defensive copy
    list.clear();
    assertEquals(2, service.findAll().size());
  }

  @Test
  @DisplayName("findById() finds existing and empty for missing")
  void testFindById() {
    service.create(new Todo(null, "A", false));
    service.create(new Todo(null, "B", true));

    assertTrue(service.findById(1).isPresent());
    assertTrue(service.findById(2).isPresent());
    assertTrue(service.findById(999).isEmpty());
  }
}
