
# Todo API (Spring Boot 3, Java 17) — with Husky pre-commit + GitHub Actions CI

This is a minimal **Java Spring Boot** Web API project that satisfies your acceptance criteria:

- ✅ `GET /api/todos` and `POST /api/todos` (smoke test)
- ✅ **Unit tests** for the Service layer (JUnit 5)
- ✅ **Husky pre-commit** hook auto-formats Java files using Spotless (google-java-format)
- ✅ **GitHub Actions CI** runs **format check** and **unit tests** on PRs

---

## Prerequisites

- Java 17
- Maven 3.8+
- Node.js 18+ and npm (for Husky hooks)

> If you change Java version, update `pom.xml` and the CI workflow (`.github/workflows/ci.yml`).

---

## Run locally (smoke test)

```bash
# 1) Build and run
mvn spring-boot:run

# 2) In another terminal, smoke test:
# GET (should return empty list on fresh start)
curl -s http://localhost:8080/api/todos | jq .

# POST (create a todo)
curl -s -X POST http://localhost:8080/api/todos   -H 'Content-Type: application/json'   -d '{"title":"Buy milk","completed":false}' | jq .

# GET again (should include the created todo)
curl -s http://localhost:8080/api/todos | jq .
```

> You can use any HTTP client (curl, Postman, REST Client in VS Code). `jq` is optional, just for pretty printing.

---

## Husky pre-commit (auto-format)

Install dependencies and set up the Git hook:

```bash
npm ci   # or: npm install
npm run prepare  # installs .git/hooks using Husky
```

Now, try committing a deliberately misformatted file (one is included at `misformatted/MisformattedExample.java`). The hook will run:

- `mvn spotless:apply` to auto-format Java sources
- `git add -A` to include the formatted changes in the commit

```bash
# Example
printf "public class X{public static void main(String[]a){System.out.println("hi");}}" > src/main/java/com/example/todo/Broken.java

git add .
# On commit, Husky will format and re-stage files
git commit -m "test: verify pre-commit auto-format"
```

> If you want the commit to **fail** when formatting is needed, switch the hook to `spotless:check` instead of `spotless:apply`.

---

## Run unit tests

```bash
mvn -q -DskipTests=false test
```

Service layer tests are in `src/test/java/com/example/todo/service/TodoServiceTest.java`.

---

## CI (GitHub Actions)

A workflow is provided at `.github/workflows/ci.yml`. It runs on push and PRs to `main` and performs:

- Spotless **format check** (`spotless:check`)
- Unit tests (`mvn -B -DskipTests=false test`)

On success, your PR will show green.

---

## Project structure

```
.
├── .github/workflows/ci.yml
├── .husky/pre-commit
├── misformatted/MisformattedExample.java
├── pom.xml
├── README.md
├── package.json
├── src
│   ├── main
│   │   ├── java/com/example/todo
│   │   │   ├── TodoApplication.java
│   │   │   ├── controller/TodoController.java
│   │   │   ├── model/Todo.java
│   │   │   └── service/TodoService.java
│   │   └── resources/application.yml
│   └── test
│       └── java/com/example/todo/service/TodoServiceTest.java
└── .gitignore
```

---

## Notes

- Storage is in-memory for simplicity (no DB). Endpoints are stateless and suitable for smoke testing.
- Formatting uses Spotless + google-java-format to keep Java code consistent. CI enforces this via `spotless:check`.
- Husky is used only for local developer experience; CI does not require Node to run Java checks.

---

## Endpoints

### `GET /api/todos`
Returns an array of todos.

### `POST /api/todos`
Creates a todo. Body example:

```json
{
  "title": "Buy milk",
  "completed": false
}
```

Response includes a generated `id`.

---

## License
MIT (do whatever you want, attribution appreciated)
